--DO NOT MODIFY THIS FILE, IT IS GENERATED AUTOMATICALLY FROM SOURCES
-- Complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "ALTER EXTENSION cdb_dataservices_client UPDATE TO '0.6.0'" to load this file. \quit
DROP FUNCTION IF EXISTS cdb_dataservices_client._obs_getmeasurebyid (text, text, text, text);
DROP FUNCTION IF EXISTS cdb_dataservices_client.obs_getmeasurebyid (text, text, text, text);
